# -*- coding: utf-8 -*-
# Module: default
# Author: cache
# Created on: 15.4.2019
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import sys
import yabop

if __name__ == '__main__':
	yabop.router(sys.argv[2][1:])
